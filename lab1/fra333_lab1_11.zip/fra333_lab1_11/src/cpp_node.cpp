#include "fra333_lab1_11/cpp_header.hpp"

#include <iostream>

int main() {
    std::cout << "Hello World!\n";
    return 0;
}
